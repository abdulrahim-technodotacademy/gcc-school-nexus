import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { UserPlus, Upload, Save, Trash2 } from "lucide-react";
import { toast } from "sonner";

const DOCUMENT_TYPES = [
  { value: "BIRTH", label: "Birth Certificate | شهادة الميلاد" },
  { value: "TRANSFER", label: "Transfer Certificate | شهادة النقل" },
  { value: "PHOTO", label: "Photograph | صورة شخصية" },
  { value: "ID", label: "ID Proof | بطاقة الهوية" },
  { value: "GUARDIAN_ID", label: "Guardian ID Document | وثيقة هوية الوصي" },
  { value: "OTHER", label: "Other | أخرى" }
];

const RELATIONSHIP_OPTIONS = [
  { value: "FATHER", label: "Father | الأب" },
  { value: "MOTHER", label: "Mother | الأم" },
  { value: "GUARDIAN", label: "Guardian | الوصي" },
  { value: "BROTHER", label: "Brother | الأخ" },
  { value: "SISTER", label: "Sister | الأخت" },
  { value: "OTHER", label: "Other | أخرى" }
];

const GENDER_OPTIONS = [
  { value: "M", label: "Male | ذكر" },
  { value: "F", label: "Female | أنثى" }
];

const NewStudentRegistrationForm = () => {
  const [formData, setFormData] = useState({
    // Student Information
    admission_number: "ADM123456",
    en_first_name: "",
    en_middle_name: "",
    en_last_name: "",
    ar_first_name: "",
    ar_middle_name: "",
    ar_last_name: "",
    photo: null as File | null,
    email: "",
    phone: "",
    date_of_birth: "",
    gender: "",
    religion: "",
    nationality: "",
    address: "",
    city: "",
    state: "",
    postal_code: "",
    country: "",
    admission_class: "",
    section: "",
    admission_date: "",
    previous_school: "",
    has_special_needs: false,
    special_needs_details: "",
    is_promoted: true,
    is_active: true,
    
    // Guardian Information
    guardian_name_en: "",
    guardian_name_ar: "",
    guardian_phone: "",
    guardian_email: "",
    guardian_address: "",
    guardian_relationship: "",
    guardian_national_id: "",
    guardian_passport_number: "",
    guardian_work_phone: "",
    guardian_home_phone: "",
    guardian_mobile: "",
    guardian_occupation: "",
    
    // Documents
    documents: [] as Array<{
      type: string;
      file: string;
      file_name: string;
    }>
  });

  const [currentDocument, setCurrentDocument] = useState({
    type: "",
    file: null as File | null
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Basic validation
    if (
      !formData.en_first_name || 
      !formData.ar_first_name || 
      !formData.date_of_birth ||
      !formData.guardian_name_en ||
      !formData.guardian_name_ar ||
      !formData.guardian_phone
    ) {
      toast.error("Please fill in all required fields");
      setIsSubmitting(false);
      return;
    }
    
    if (formData.documents.length === 0) {
      toast.error("Please upload at least one document");
      setIsSubmitting(false);
      return;
    }

    // Prepare data for API
    const registrationData = {
      guardian: {
        name_en: formData.guardian_name_en,
        name_ar: formData.guardian_name_ar,
        phone: formData.guardian_phone,
        email: formData.guardian_email,
        address: formData.guardian_address,
        relationship: formData.guardian_relationship,
        national_id: formData.guardian_national_id,
        passport_number: formData.guardian_passport_number,
        work_phone: formData.guardian_work_phone,
        home_phone: formData.guardian_home_phone,
        mobile: formData.guardian_mobile,
        occupation: formData.guardian_occupation
      },
      student: {
        admission_number: formData.admission_number,
        en_first_name: formData.en_first_name,
        en_middle_name: formData.en_middle_name,
        en_last_name: formData.en_last_name,
        ar_first_name: formData.ar_first_name,
        ar_middle_name: formData.ar_middle_name,
        ar_last_name: formData.ar_last_name,
        photo: formData.photo ? await convertToBase64(formData.photo) : null,
        email: formData.email,
        phone: formData.phone,
        date_of_birth: formData.date_of_birth,
        age_years: calculateAge(formData.date_of_birth),
        gender: formData.gender,
        religion: formData.religion,
        nationality: formData.nationality,
        address: formData.address,
        city: formData.city,
        state: formData.state,
        postal_code: formData.postal_code,
        country: formData.country,
        admission_class: formData.admission_class,
        section: formData.section,
        admission_date: formData.admission_date,
        previous_school: formData.previous_school,
        has_special_needs: formData.has_special_needs,
        special_needs_details: formData.special_needs_details,
        is_promoted: formData.is_promoted,
        is_active: formData.is_active,
        is_verified_registration_officer: true
      },
      documents: formData.documents.map(doc => ({
        document_type: doc.type,
        file_data: doc.file,
        file_name: doc.file_name || `document_${Date.now()}`
      }))
    };

    try {
      const accessToken = localStorage.getItem("accessToken");
      if (!accessToken) {
        throw new Error("Authentication token not found");
      }

      const response = await fetch("http://139.59.69.37:8080/mawhiba/api/v1/students/create-student-details/", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${accessToken}`
        },
        body: JSON.stringify(registrationData)
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to submit registration");
      }

      const result = await response.json();
      toast.success("Registration submitted successfully!");
      
      // Reset form
      setFormData({
        admission_number: "",
        en_first_name: "",
        en_middle_name: "",
        en_last_name: "",
        ar_first_name: "",
        ar_middle_name: "",
        ar_last_name: "",
        photo: null,
        email: "",
        phone: "",
        date_of_birth: "",
        gender: "",
        religion: "",
        nationality: "",
        address: "",
        city: "",
        state: "",
        postal_code: "",
        country: "",
        admission_class: "",
        section: "",
        admission_date: "",
        previous_school: "",
        has_special_needs: false,
        special_needs_details: "",
        is_promoted: true,
        is_active: true,
        guardian_name_en: "",
        guardian_name_ar: "",
        guardian_phone: "",
        guardian_email: "",
        guardian_address: "",
        guardian_relationship: "",
        guardian_national_id: "",
        guardian_passport_number: "",
        guardian_work_phone: "",
        guardian_home_phone: "",
        guardian_mobile: "",
        guardian_occupation: "",
        documents: []
      });
    } catch (error) {
      console.error("Registration error:", error);
      toast.error(error instanceof Error ? error.message : "Failed to submit registration");
    } finally {
      setIsSubmitting(false);
    }
  };

  const convertToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = error => reject(error);
    });
  };

  const calculateAge = (dateOfBirth: string): number => {
    const dob = new Date(dateOfBirth);
    const today = new Date();
    let age = today.getFullYear() - dob.getFullYear();
    const monthDiff = today.getMonth() - dob.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < dob.getDate())) {
      age--;
    }
    return age;
  };

  const handleFileUpload = () => {
    if (!currentDocument.type || !currentDocument.file) {
      toast.error("Please select document type and upload a file");
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const newDocument = {
        type: currentDocument.type,
        file: reader.result as string,
        file_name: currentDocument.file?.name || ""
      };

      setFormData({
        ...formData,
        documents: [...formData.documents, newDocument]
      });

      setCurrentDocument({
        type: "",
        file: null
      });

      toast.success("Document uploaded successfully");
    };
    reader.readAsDataURL(currentDocument.file);
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFormData({
        ...formData,
        photo: e.target.files[0]
      });
      toast.success("Student photo uploaded");
    }
  };

  const removeDocument = (index: number) => {
    const updatedDocs = [...formData.documents];
    updatedDocs.splice(index, 1);
    setFormData({
      ...formData,
      documents: updatedDocs
    });
  };

  return (
    <Card className="max-w-4xl mx-auto mt-20 p-6 bg-white shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <UserPlus className="h-5 w-5" />
          New Student Registration | تسجيل طالب جديد
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Student Information Section */}
          <div>
            <h3 className="text-lg font-semibold mb-4 border-b pb-2">
              Student Information | معلومات الطالب
            </h3>
            
            <div className="grid md:grid-cols-2 gap-4">
              {/* Admission Number */}
              <div>
                <Label htmlFor="admission_number">Admission Number | رقم القبول</Label>
                <Input
                  id="admission_number"
                  value={formData.admission_number}
                  onChange={(e) => setFormData({...formData, admission_number: e.target.value})}
                  placeholder="ADM123456"
                />
              </div>

              {/* Student Photo */}
              <div>
                <Label htmlFor="photo">Student Photo | صورة الطالب</Label>
                <div className="flex items-center gap-2">
                  <Input
                    id="photo"
                    type="file"
                    accept="image/*"
                    onChange={handlePhotoUpload}
                  />
                  {formData.photo && (
                    <span className="text-sm">{formData.photo.name}</span>
                  )}
                </div>
              </div>

              {/* English Name */}
              <div>
                <Label htmlFor="en_first_name">First Name (English) * | الاسم الأول (إنجليزي)</Label>
                <Input
                  id="en_first_name"
                  value={formData.en_first_name}
                  onChange={(e) => setFormData({...formData, en_first_name: e.target.value})}
                  placeholder="First name in English"
                  required
                />
              </div>

              <div>
                <Label htmlFor="en_middle_name">Middle Name (English) | الاسم الأوسط (إنجليزي)</Label>
                <Input
                  id="en_middle_name"
                  value={formData.en_middle_name}
                  onChange={(e) => setFormData({...formData, en_middle_name: e.target.value})}
                  placeholder="Middle name in English"
                />
              </div>

              <div>
                <Label htmlFor="en_last_name">Last Name (English) | اسم العائلة (إنجليزي)</Label>
                <Input
                  id="en_last_name"
                  value={formData.en_last_name}
                  onChange={(e) => setFormData({...formData, en_last_name: e.target.value})}
                  placeholder="Last name in English"
                />
              </div>

              {/* Arabic Name */}
              <div>
                <Label htmlFor="ar_first_name">First Name (Arabic) * | الاسم الأول (عربي)</Label>
                <Input
                  id="ar_first_name"
                  value={formData.ar_first_name}
                  onChange={(e) => setFormData({...formData, ar_first_name: e.target.value})}
                  placeholder="الاسم الأول بالعربية"
                  dir="rtl"
                  required
                />
              </div>

              <div>
                <Label htmlFor="ar_middle_name">Middle Name (Arabic) | الاسم الأوسط (عربي)</Label>
                <Input
                  id="ar_middle_name"
                  value={formData.ar_middle_name}
                  onChange={(e) => setFormData({...formData, ar_middle_name: e.target.value})}
                  placeholder="الاسم الأوسط بالعربية"
                  dir="rtl"
                />
              </div>

              <div>
                <Label htmlFor="ar_last_name">Last Name (Arabic) | اسم العائلة (عربي)</Label>
                <Input
                  id="ar_last_name"
                  value={formData.ar_last_name}
                  onChange={(e) => setFormData({...formData, ar_last_name: e.target.value})}
                  placeholder="اسم العائلة بالعربية"
                  dir="rtl"
                />
              </div>

              {/* Contact Information */}
              <div>
                <Label htmlFor="email">Email | البريد الإلكتروني</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  placeholder="student@example.com"
                />
              </div>

              <div>
                <Label htmlFor="phone">Phone | الهاتف</Label>
                <Input
                  id="phone"
                  value={formData.phone}
                  onChange={(e) => setFormData({...formData, phone: e.target.value})}
                  placeholder="+1234567890"
                />
              </div>

              {/* Personal Information */}
              <div>
                <Label htmlFor="date_of_birth">Date of Birth * | تاريخ الميلاد</Label>
                <Input
                  id="date_of_birth"
                  type="date"
                  value={formData.date_of_birth}
                  onChange={(e) => setFormData({...formData, date_of_birth: e.target.value})}
                  required
                />
              </div>

              <div>
                <Label htmlFor="gender">Gender * | الجنس</Label>
                <Select
                  value={formData.gender}
                  onValueChange={(value) => setFormData({...formData, gender: value})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select gender" />
                  </SelectTrigger>
                  <SelectContent>
                    {GENDER_OPTIONS.map((gender) => (
                      <SelectItem key={gender.value} value={gender.value}>
                        {gender.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="religion">Religion | الديانة</Label>
                <Input
                  id="religion"
                  value={formData.religion}
                  onChange={(e) => setFormData({...formData, religion: e.target.value})}
                  placeholder="Religion"
                />
              </div>

              <div>
                <Label htmlFor="nationality">Nationality | الجنسية</Label>
                <Input
                  id="nationality"
                  value={formData.nationality}
                  onChange={(e) => setFormData({...formData, nationality: e.target.value})}
                  placeholder="Nationality"
                />
              </div>

              {/* Address Information */}
              <div>
                <Label htmlFor="address">Address | العنوان</Label>
                <Input
                  id="address"
                  value={formData.address}
                  onChange={(e) => setFormData({...formData, address: e.target.value})}
                  placeholder="123 Main St, City, Country"
                />
              </div>

              <div>
                <Label htmlFor="city">City | المدينة</Label>
                <Input
                  id="city"
                  value={formData.city}
                  onChange={(e) => setFormData({...formData, city: e.target.value})}
                  placeholder="City"
                />
              </div>

              <div>
                <Label htmlFor="state">State | المحافظة</Label>
                <Input
                  id="state"
                  value={formData.state}
                  onChange={(e) => setFormData({...formData, state: e.target.value})}
                  placeholder="State"
                />
              </div>

              <div>
                <Label htmlFor="postal_code">Postal Code | الرمز البريدي</Label>
                <Input
                  id="postal_code"
                  value={formData.postal_code}
                  onChange={(e) => setFormData({...formData, postal_code: e.target.value})}
                  placeholder="Postal code"
                />
              </div>

              <div>
                <Label htmlFor="country">Country | الدولة</Label>
                <Input
                  id="country"
                  value={formData.country}
                  onChange={(e) => setFormData({...formData, country: e.target.value})}
                  placeholder="Country"
                />
              </div>

              {/* School Information */}
              <div>
                <Label htmlFor="admission_class">Admission Class | الصف الدراسي</Label>
                <Input
                  id="admission_class"
                  value={formData.admission_class}
                  onChange={(e) => setFormData({...formData, admission_class: e.target.value})}
                  placeholder="Class ID"
                />
              </div>

              <div>
                <Label htmlFor="section">Section | القسم</Label>
                <Input
                  id="section"
                  value={formData.section}
                  onChange={(e) => setFormData({...formData, section: e.target.value})}
                  placeholder="Section ID"
                />
              </div>

              <div>
                <Label htmlFor="admission_date">Admission Date | تاريخ القبول</Label>
                <Input
                  id="admission_date"
                  type="date"
                  value={formData.admission_date}
                  onChange={(e) => setFormData({...formData, admission_date: e.target.value})}
                />
              </div>

              <div>
                <Label htmlFor="previous_school">Previous School | المدرسة السابقة</Label>
                <Input
                  id="previous_school"
                  value={formData.previous_school}
                  onChange={(e) => setFormData({...formData, previous_school: e.target.value})}
                  placeholder="Previous school name"
                />
              </div>

              {/* Special Needs */}
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="has_special_needs"
                  checked={formData.has_special_needs}
                  onChange={(e) => setFormData({...formData, has_special_needs: e.target.checked})}
                />
                <Label htmlFor="has_special_needs">Has Special Needs | لديه احتياجات خاصة</Label>
              </div>

              {formData.has_special_needs && (
                <div>
                  <Label htmlFor="special_needs_details">Special Needs Details | تفاصيل الاحتياجات الخاصة</Label>
                  <Input
                    id="special_needs_details"
                    value={formData.special_needs_details}
                    onChange={(e) => setFormData({...formData, special_needs_details: e.target.value})}
                    placeholder="Details about special needs"
                  />
                </div>
              )}
            </div>
          </div>

          {/* Guardian Information Section */}
          <div>
            <h3 className="text-lg font-semibold mb-4 border-b pb-2">
              Guardian Information | معلومات ولي الأمر
            </h3>
            
            <div className="grid md:grid-cols-2 gap-4">
              {/* Guardian English Name */}
              <div>
                <Label htmlFor="guardian_name_en">Name (English) * | الاسم (إنجليزي)</Label>
                <Input
                  id="guardian_name_en"
                  value={formData.guardian_name_en}
                  onChange={(e) => setFormData({...formData, guardian_name_en: e.target.value})}
                  placeholder="Guardian name in English"
                  required
                />
              </div>
              
              {/* Guardian Arabic Name */}
              <div>
                <Label htmlFor="guardian_name_ar">Name (Arabic) * | الاسم (عربي)</Label>
                <Input
                  id="guardian_name_ar"
                  value={formData.guardian_name_ar}
                  onChange={(e) => setFormData({...formData, guardian_name_ar: e.target.value})}
                  placeholder="اسم ولي الأمر بالعربية"
                  dir="rtl"
                  required
                />
              </div>
              
              {/* Contact Information */}
              <div>
                <Label htmlFor="guardian_phone">Phone * | الهاتف</Label>
                <Input
                  id="guardian_phone"
                  value={formData.guardian_phone}
                  onChange={(e) => setFormData({...formData, guardian_phone: e.target.value})}
                  placeholder="+1234567890"
                  required
                />
              </div>

              <div>
                <Label htmlFor="guardian_email">Email | البريد الإلكتروني</Label>
                <Input
                  id="guardian_email"
                  type="email"
                  value={formData.guardian_email}
                  onChange={(e) => setFormData({...formData, guardian_email: e.target.value})}
                  placeholder="guardian@example.com"
                />
              </div>

              <div>
                <Label htmlFor="guardian_mobile">Mobile | الجوال</Label>
                <Input
                  id="guardian_mobile"
                  value={formData.guardian_mobile}
                  onChange={(e) => setFormData({...formData, guardian_mobile: e.target.value})}
                  placeholder="+1122334455"
                />
              </div>

              <div>
                <Label htmlFor="guardian_work_phone">Work Phone | هاتف العمل</Label>
                <Input
                  id="guardian_work_phone"
                  value={formData.guardian_work_phone}
                  onChange={(e) => setFormData({...formData, guardian_work_phone: e.target.value})}
                  placeholder="+9876543210"
                />
              </div>

              <div>
                <Label htmlFor="guardian_home_phone">Home Phone | الهاتف المنزلي</Label>
                <Input
                  id="guardian_home_phone"
                  value={formData.guardian_home_phone}
                  onChange={(e) => setFormData({...formData, guardian_home_phone: e.target.value})}
                  placeholder="+192837465"
                />
              </div>

              {/* Relationship */}
              <div>
                <Label htmlFor="guardian_relationship">Relationship * | العلاقة</Label>
                <Select
                  value={formData.guardian_relationship}
                  onValueChange={(value) => setFormData({...formData, guardian_relationship: value})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select relationship" />
                  </SelectTrigger>
                  <SelectContent>
                    {RELATIONSHIP_OPTIONS.map((relation) => (
                      <SelectItem key={relation.value} value={relation.value}>
                        {relation.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="guardian_occupation">Occupation | المهنة</Label>
                <Input
                  id="guardian_occupation"
                  value={formData.guardian_occupation}
                  onChange={(e) => setFormData({...formData, guardian_occupation: e.target.value})}
                  placeholder="Occupation"
                />
              </div>

              {/* Identification */}
              <div>
                <Label htmlFor="guardian_national_id">National ID | الهوية الوطنية</Label>
                <Input
                  id="guardian_national_id"
                  value={formData.guardian_national_id}
                  onChange={(e) => setFormData({...formData, guardian_national_id: e.target.value})}
                  placeholder="A123456789"
                />
              </div>

              <div>
                <Label htmlFor="guardian_passport_number">Passport Number | رقم الجواز</Label>
                <Input
                  id="guardian_passport_number"
                  value={formData.guardian_passport_number}
                  onChange={(e) => setFormData({...formData, guardian_passport_number: e.target.value})}
                  placeholder="P987654321"
                />
              </div>

              {/* Address */}
              <div className="md:col-span-2">
                <Label htmlFor="guardian_address">Address | العنوان</Label>
                <Input
                  id="guardian_address"
                  value={formData.guardian_address}
                  onChange={(e) => setFormData({...formData, guardian_address: e.target.value})}
                  placeholder="123 Main St, City, Country"
                />
              </div>
            </div>
          </div>

          {/* Documents Upload Section */}
          <div>
            <h3 className="text-lg font-semibold mb-4 border-b pb-2">
              Required Documents | الوثائق المطلوبة
            </h3>
            
            {/* Uploaded Documents List */}
            {formData.documents.length > 0 && (
              <div className="mb-4 space-y-2">
                <h4 className="font-medium">Uploaded Documents | الوثائق المرفوعة</h4>
                {formData.documents.map((doc, index) => (
                  <div key={index} className="flex items-center justify-between p-2 border rounded">
                    <div className="flex flex-col">
                      <span>
                        {DOCUMENT_TYPES.find(t => t.value === doc.type)?.label.split('|')[0].trim()}
                      </span>
                      {doc.file_name && <span className="text-xs text-gray-500">{doc.file_name}</span>}
                    </div>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => removeDocument(index)}
                      className="text-red-500 hover:text-red-700"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
            
            {/* Document Upload Form */}
            <div className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                {/* Document Type */}
                <div>
                  <Label htmlFor="document_type">Document Type | نوع الوثيقة</Label>
                  <Select
                    value={currentDocument.type}
                    onValueChange={(value) => setCurrentDocument({...currentDocument, type: value})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select document type" />
                    </SelectTrigger>
                    <SelectContent>
                      {DOCUMENT_TYPES.map((type) => (
                        <SelectItem key={type.value} value={type.value}>
                          {type.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                {/* File Upload */}
                <div>
                  <Label htmlFor="document_file">File | الملف</Label>
                  <div className="flex items-center gap-2">
                    <Input
                      id="document_file"
                      type="file"
                      accept=".pdf,.jpg,.jpeg,.png"
                      onChange={(e) => setCurrentDocument({
                        ...currentDocument,
                        file: e.target.files?.[0] || null
                      })}
                    />
                    <Upload className="h-4 w-4 text-gray-400" />
                  </div>
                </div>
              </div>
              
              <Button
                type="button"
                onClick={handleFileUpload}
                variant="outline"
                className="w-full"
                disabled={!currentDocument.type || !currentDocument.file}
              >
                Add Document | إضافة وثيقة
              </Button>
            </div>
          </div>

          {/* Submit Button */}
          <Button 
            type="submit" 
            size="lg" 
            className="w-full bg-green-600 hover:bg-green-700"
            disabled={isSubmitting}
          >
            {isSubmitting ? (
              "Submitting..."
            ) : (
              <>
                <Save className="mr-2 h-5 w-5" />
                Register Student | تسجيل الطالب
              </>
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};

export default NewStudentRegistrationForm;